orangtua(usman, anti).
orangtua(usman, nurman).
orangtua(usman, sumarni).
orangtua(nurheda, anti).
orangtua(nurheda, nurman).
orangtua(nurheda, sumarni).

orangtua(sumarni, indra).
orangtua(sumarni, ahmad).
orangtua(sumarni, safwan).
orangtua(sumarni, salfa).
orangtua(salman, indra).
orangtua(salman, ahmad).
orangtua(salman, safwan).
orangtua(salman, salfa).

laki(usman).
laki(nurman).
laki(salman).
laki(indra).
laki(ahmad).
laki(safwan).

perempuan(nurheda).
perempuan(anti).
perempuan(sumarni).
perempuan(salfa).

ibu(X,Y) :-orangtua(X,Y), perempuan(X).
ayah(X,Y) :-orangtua(X,Y), laki(X).

anak(X,Y) :-orangtua(X,Y).
anaklaki_laki(X,Y) :-orangtua(Y,X), laki(X).
anakperempuan(X,Y) :-orangtua(Y,X), perempuan(X).

menikah(X,Y) :-anak(P,X), anak(P,Y), laki(X).
istri(Y,X) :-anak(P,X), anak(P,Y), perempuan(Y).
suami(Y,X) :-anak(P,X), anak(P,Y), perempuan(Y).

kakek(X,Z) :- orangtua(X,Y), orangtua(Y,Z), laki(X).
nenek(X,Z) :- ibu(X,Y), ibu(Y,Z).

saudara(Y,Z) :-anak(Y,X), anak(Z,X), Y\=Z.
saudaralaki_laki(Y,Z) :-anak(Y,X), anak(Z,X), laki(Y), Y\=Z.
saudaraperempuan(Y,Z) :-anak(Y,X), anak(Z,X), perempuan(Y), Y\=Z.

bibi(X,Y) :-saudara(X,Z), orangtua(Y,Z), perempuan(X), not(ibu(X,Y)).
paman(X,Y) :-saudara(X,Z), orangtua(Z,Y), laki(X), not(ayah(X,Y)).

cuculaki(X,Z) :-anak(X,Y), orangtua(Z,Y), laki(X).
cucuperempuan(X,Z) :-anak(X,Y), orangtua(Z,Y), perempuan(X).
